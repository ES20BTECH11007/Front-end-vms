import "./App.css";
import React from "react";
import { Routes, Route, BrowserRouter as Router } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./components/Home";
import Members from "./components/Team";
import Menu from "./components/NavigationSport"
import Events from "./components/Events";
import Login from "./components/nso";
import LoginC from "./components/COORD";
import VBup from "./components/vb_scup";
import CoordinatorPage from "./components/coord_loggedin";
import MatchSlider from "./components/specpage";
import PlayerSearch from "./components/player";



function App() {
  return (
    <div className="App">
      <Router >
      <Navbar />
        <Routes>
          <Route path="/" element={<Home/> } />
          <Route path="/SPORTNAVIGATION" element={<Menu/> } />
          <Route path="/coord" element={<LoginC/>} />
          <Route path="/events" element={<Events />} />
          <Route path="/NSOPORTAL" element={<Login/>} />
          <Route path="/Team" element={<Members />} />
          <Route path="/vbup" element={<VBup />} />
          <Route path="/cood_login" element={<CoordinatorPage />} />
          <Route path="/specpage" element={<MatchSlider />} />
          <Route path="/player" element={<PlayerSearch />} />

        </Routes>
      <Footer />
    </Router>
   
  </div>
  );
}

export default App;
