import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import '../css/matchslider.css';

const matchData = [
  { id: 1, team1: 'Team A', team2: 'Team B', score1: 2, score2: 1 },
  { id: 2, team1: 'Team C', team2: 'Team D', score1: 3, score2: 3 },
  { id: 3, team1: 'Team E', team2: 'Team F', score1: 0, score2: 2 },
  { id: 4, team1: 'Team G', team2: 'Team H', score1: 1, score2: 1 },
];

const MatchSlider = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  return (
    <div className="match-slider-container">
      <Slider {...settings}>
        {matchData.map((match) => (
          <div key={match.id}>
            <h2>
              {match.team1} vs {match.team2}
            </h2>
            <p>
              {match.score1} - {match.score2}
            </p>
          </div>
        ))}
      </Slider>
      <button onClick={() => window.location.href='/player'}>
        Know Your Player
      </button>
    </div>
  );
};

export default MatchSlider;
