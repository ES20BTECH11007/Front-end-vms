import React, { useState } from "react";
import '../css/scup.css';

function Options() {
  const [option1Selected, setOption1Selected] = useState(false);
  const [option2Selected, setOption2Selected] = useState(false);

  const handleOption1Click = () => {
    setOption1Selected(true);
    setOption2Selected(false);
  };

  const handleOption2Click = () => {
    setOption1Selected(false);
    setOption2Selected(true);
  };
  

  return (
    <div className="options-container">
      <button
        className={option1Selected ? "option-button selected" : "option-button"}
        onClick={handleOption1Click}
      >
        Option 1
      </button>
      <button
        className={option2Selected ? "option-button selected" : "option-button"}
        onClick={handleOption2Click}
      >
        Option 2
      </button>
    </div>
  );
}

export default Options;