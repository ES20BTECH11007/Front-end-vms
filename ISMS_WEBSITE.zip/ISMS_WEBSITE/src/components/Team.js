import * as React from "react";
import "../sass/main.css";
import teamData from "./MembersList";

const ImageDiv = (props) => {
  return (
    <div className="members__block">
      <img className="members__photo" src={props.image} alt="" />
      <h3 className="heading-teritiary members__name">{props.name}</h3>
    </div>
  );
};

const Members = () => {
  return (
    <div className="members">
      <div className="members__container">
      <h2 className="heading-secondary members__heading main">SPORTS COUNCIL </h2>
        <div>
          <h2 className="heading-secondary members__heading main  overall">
            FIC SPORTS
          </h2>
          <ImageDiv image={teamData.sports} name="FIC Sports" />
        </div>


        
        <div>
          <h2 className="heading-secondary members__heading">
            Sports Secretary 
          </h2>

          <ImageDiv image={teamData.sports} name="Varun" />
        </div>


        <div>
          <h2 className="heading-secondary members__heading">
            Cricket 
          </h2>
          <ImageDiv image={teamData.sports}  name="coordinator" />
        </div>


        <div>
          <h2 className="heading-secondary members__heading">Athletics</h2>
          <ImageDiv image={teamData.sports} name="coordinator" />
        </div>

        <div>
          <h2 className="heading-secondary members__heading">
            Aquatics
          </h2>
          <ImageDiv image={teamData.sports} name="coordinator" />
        </div>


        <div>
          <h2 className="heading-secondary members__heading">Volley ball</h2>
          <ImageDiv image={teamData.sports} name="coordinator" />
        </div>

        <div>
          <h2 className="heading-secondary members__heading">
            BasketBall
          </h2>
          <ImageDiv
            image={teamData.sports}
            name="coordinator"
          />
        </div>


        <div>
          <h2 className="heading-secondary members__heading">
            TENNIS
          </h2>
          <ImageDiv image={teamData.sports} name="coordinator" />
        
        </div>


        <div>
          <h2 className="heading-secondary members__heading">
            Badminton
          </h2>
          <ImageDiv image={teamData.sports} name="coordinator" />
          
        </div>

        <div>
          <h2 className="heading-secondary members__heading">
            FootBall
          </h2>
          <ImageDiv image={teamData.sports} name="coordinator" />
          
        </div>


        <div>
          <h2 className="heading-secondary members__heading">
            HOCKEY
          </h2>
          <ImageDiv image={teamData.sports} name="coordinator" />
          
        </div>

        <div>
          <h2 className="heading-secondary members__heading">
            TABLE TENNIS
          </h2>
          <ImageDiv image={teamData.sports} name="coordinator" />
          
        </div>

        <div>
          <h2 className="heading-secondary members__heading">
            SQUASH
          </h2>
          <ImageDiv image={teamData.sports} name="coordinator" />
          
        </div>

        <div>
          <h2 className="heading-secondary members__heading">
            CHESS
          </h2>
          <ImageDiv image={teamData.sports} name="coordinator" />
          
        </div>

        <div>
          <h2 className="heading-secondary members__heading">
            ESPORTS
          </h2>
          <ImageDiv image={teamData.sports} name="coordinator" />
          
        </div>


      
      
        
        </div>
      </div>
   
  );
};

export default Members;
