// import React, { useState } from "react";

// function LoginC() {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");

//   const handleEmailChange = (event) => {
//     setEmail(event.target.value);
//   };

//   const handlePasswordChange = (event) => {
//     setPassword(event.target.value);
//   };

//   const handleSubmit = async (event) => {
//     event.preventDefault();
//     const response = await fetch("http://localhost:3001/COORD", {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json"
//       },
//       body: JSON.stringify({ email, password })
//     });

//     const data = await response.text();
//     console.log(data);

    
//     // handle the response from the server here
//   };

//   return (
//     <form onSubmit={handleSubmit}>
//       <label>
//         Email:
//         <input type="email" value={email} onChange={handleEmailChange} />
//       </label>
//       <label>
//         Password:
//         <input type="password" value={password} onChange={handlePasswordChange} />
//       </label>
//       <button type="submit">Log In</button>
//     </form>
//   );
// }

// export default LoginC;


import { useState } from 'react';
import axios from 'axios';

export default function LoginC() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await axios.post('http://localhost:3001/COORD', { email, password });
      setMessage(response.data.message);
      // If login is successful, redirect the user to the dashboard page
      if (response.status === 200) {
        window.location.href = '/cood_login';
      }
    } catch (error) {
      setMessage('Login failed');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Email:
        <input type="text" value={email} onChange={(e) => setEmail(e.target.value)} />
      </label>
      <label>
        Password:
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
      </label>
      <button type="submit">Login</button>
      {message && <p>{message}</p>}
    </form>
  );
}

