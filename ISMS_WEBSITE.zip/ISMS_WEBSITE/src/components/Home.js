import * as React from "react";
import "../sass/main.css";
import Section1 from "../components/Section1";
import Slider from "../components/Slider";
import Header from "../components/Header";

const Home = () => {
  return (
    <div>
      <Header />
      <Section1 />
      <Slider />
    </div>
  );
};

export default Home;
