// import React from 'react';
import '../css/Login.css';

// const Login = () => {
//   return (
//     <div className="login-wrapper">
//       <h2>Sign in to your account</h2>
//       <form>
//         <label htmlFor="email">Email address:</label>
//         <input type="email" id="email" name="email" placeholder="Enter your email address" required />
//         <label htmlFor="password">Password:</label>
//         <input type="password" id="password" name="password" placeholder="Enter your password" required />
//         <button type="submit">Sign In</button>
//       </form>
//     </div>
//   );
// };

// export default Login;

import React, { useState } from 'react';
import axios from 'axios';

function Login() {
  const [id, setId] = useState('');
  const [pw, setPw] = useState('');
  const [hours, SetHours] = useState(null);

  // const setUser = (data) => {
  //   const { id, email } = data;
  //   const user = { id, email };
  //   setUser(user);
  // };
  
  

  const handleSubmit = (event) => {
    console.log('jbaefihsa')
    event.preventDefault();
    axios.post('http://localhost:3001/submit', { id, pw })
      .then(response => {
        if(response.status === 200)
        {
          SetHours(response.data.Hours);
        }
        
      })
      .catch(error => {
        console.error(error);
      });
  };

  return (
    <form onSubmit={handleSubmit}>
      <label htmlFor="id">ID:</label>
      <input type="text" id="id" value={id} onChange={e => setId(e.target.value)} />
      <br />
      <label htmlFor="pw">Password:</label>
      <input type="password" id="pw" value={pw} onChange={e => setPw(e.target.value)} />
      <br />
      <button type="submit">Submit</button>
      <br />
      
      {hours && (
        
        <div>
          <p> NUMBER OF HOURS COMPLETED : {hours}</p>
        </div>
      )}
    </form>
  
  );
}

export default Login;
