const teamData = {
    sports: require("../Assets/iith_sportslogo.png"),
    
  };
  
  export default teamData;