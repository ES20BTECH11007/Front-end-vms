import * as React from "react";
import "../sass/main.css";
import picture1 from "../Assets/INTERIIT1.jpeg";
import picture2 from "../Assets/INTERIIT2.jpeg";
import picture3 from "../Assets/INTERIIT3.jpeg";
import picture4 from "../Assets/INTERIIT3.jpeg";

const Section1 = () => {
  return (
    <section className="section-about" id="section1">
      <div className="grid grid-2">
        <div className="left">
          <h3 className="left__heading heading-secondary">
            Welcome to Sports <br></br>IIT Hyderbad.
          </h3>
          <p className="left__about">
          IIT Hyderabad,  is an eminent and promising institute of technology. It has made quite a name in the short span of around 15 years from its establishment in 2008. Being present in a city of great history and culture , of grooming young and innovative minds , IIT H has shown, and will continue to show its commitment in taking this forward. Everyone at IITH is striving hard and chasing their passion towards making the society a better place for everyone
          </p>
        </div>
        <div className="composition">
          <a href="https://drive.google.com/drive/folders/1G6gjsbtfzVguDTVe7-prbXM21p2c0Y76"><img
            src={picture1}
            alt="photo-1"
            className="composition__photo composition__photo--p1"
          /></a>
           <a href="https://drive.google.com/drive/folders/1urir7s3Dx95kQsm2PpK6OXHLEmuHP2Xg"><img
            src={picture2}
            alt="photo-1"
            className="composition__photo composition__photo--p2"
          /></a>
           <a><img
            src={picture3}
            alt="photo-3"
            className="composition__photo composition__photo--p3"
          /></a>

       
          
        </div>
      </div>
    </section>
  );
};

export default Section1;
