import React from 'react';
import '../css/menu.css';
import item1Image from '../Assets/Cricket.jpg';
import item2Image from '../Assets/volleyball.png';
import item3Image from '../Assets/basketball.jpg';
import item4Image from '../Assets/tennis.jpeg';
import item5Image from '../Assets/badminton.jpg';
import item6Image from '../Assets/football.jpg';
import item7Image from '../Assets/hockey.jpg';
import item8Image from '../Assets/aquatics.jpeg';
import item9Image from '../Assets/athletics.jpg';
import item10Image from '../Assets/tt.jpeg';
import item11Image from '../Assets/squash.jfif';
import item12Image from '../Assets/chess.jpg';
import item13Image from '../Assets/esports.jpg';

const Menu = () => {
  return (
    <div className="menu-wrapper">
      <div className="menu-container">
        <a href="/specpage" className="menu-item">
          <img src={item1Image} alt="Cricket" />
          <span>Cricket</span>
        </a>
        <a href="/specpage" className="menu-item">
          <img src={item2Image} alt="Volleyball" />
          <span>Volleball</span>
        </a>
        <a href="/specpage" className="menu-item">
          <img src={item3Image} alt="Basketball" />
          <span>Basketball</span>
        </a>
        <a href="/specpage" className="menu-item">
          <img src={item4Image} alt="Tennis" />
          <span>Tennis</span>
        </a>
        <a href="/specpage" className="menu-item">
          <img src={item5Image} alt="Badminton" />
          <span>Badminton</span>
        </a>
        <a href="/specpage" className="menu-item">
          <img src={item6Image} alt="Football" />
          <span>Football</span>
        </a>
        <a href="/specpage" className="menu-item">
          <img src={item7Image} alt="Hockey" />
          <span>Hockey</span>
        </a>
        <a href="/specpage" className="menu-item">
          <img src={item8Image} alt="Aquatics" />
          <span>Aquatics</span>
        </a>
        <a href="/specpage" className="menu-item">
          <img src={item9Image} alt="Athletics" />
          <span>Athletics</span>
        </a>
        <a href="/specpage" className="menu-item">
          <img src={item10Image} alt="Table Tennis" />
          <span>Table Tennis</span>
        </a>
        <a href="/specpage" className="menu-item">
          <img src={item11Image} alt="Squash" />
          <span>Squash</span>
        </a>
        <a href="/specpage" className="menu-item">
          <img src={item12Image} alt="Chess" />
          <span>Chess</span>
        </a>
        <a href="/specpage" className="menu-item">
          <img src={item13Image} alt="Esports" />
          <span>Esports</span>
        </a>
      </div>
    </div>
  );
};

export default Menu;