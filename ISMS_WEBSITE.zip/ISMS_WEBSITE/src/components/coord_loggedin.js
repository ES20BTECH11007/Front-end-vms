import React, { useState } from 'react';
import '../css/coordinatorPage.css';

export default function CoordinatorPage() {
  const [tournamentName, setTournamentName] = useState('');
  const [tournamentStartDate, setTournamentStartDate] = useState('');
  const [tournamentEndDate, setTournamentEndDate] = useState('');
  const [tournamentRules, setTournamentRules] = useState('');
  const [teams, setTeams] = useState([]);
  const [matches, setMatches] = useState([]);

  const handleCreateTournament = () => {
    // Send a POST request to the backend with the tournament data
    fetch('/api/tournaments', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: tournamentName,
        start_date: tournamentStartDate,
        end_date: tournamentEndDate,
        rules: tournamentRules,
        teams: teams,
      }),
    })
      .then((response) => response.json())
      .then((data) => console.log(data))
      .catch((error) => console.error(error));
  };

  const handleAddTeam = (event) => {
    event.preventDefault();
    const teamName = event.target.elements.teamName.value;
    setTeams([...teams, teamName]);
    event.target.elements.teamName.value = '';
  };

  const handleShuffleMatches = () => {
    // Send a POST request to the backend to shuffle the matches
    fetch(`/api/tournaments/${1}/matches/shuffle`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        teams: teams,
      }),
    })
      .then((response) => response.json())
      .then((data) => setMatches(data))
      .catch((error) => console.error(error));
  };

  return (
    <div>
      <h1>Create Tournament</h1>
      <form>
        <label htmlFor="name">Tournament Name:</label>
        <input
          type="text"
          id="name"
          value={tournamentName}
          onChange={(event) => setTournamentName(event.target.value)}
        />
        <label htmlFor="start-date">Start Date:</label>
        <input
          type="date"
          id="start-date"
          value={tournamentStartDate}
          onChange={(event) => setTournamentStartDate(event.target.value)}
        />
        <label htmlFor="end-date">End Date:</label>
        <input
          type="date"
          id="end-date"
          value={tournamentEndDate}
          onChange={(event) => setTournamentEndDate(event.target.value)}
        />
        <label htmlFor="rules">Rules:</label>
        <textarea
          id="rules"
          value={tournamentRules}
          onChange={(event) => setTournamentRules(event.target.value)}
        />
        <h2>Add Teams</h2>
        <form onSubmit={handleAddTeam}>
          <label htmlFor="teamName">Team Name:</label>
          <input type="text" id="teamName" />
          <button type="submit">Add Team</button>
        </form>
        <ul>
          {teams.map((team, index) => (
            <li key={index}>{team}</li>
          ))}
        </ul>
        <button type="button" onClick={handleCreateTournament}>
          Create Tournament
        </button>
      </form>

      <h1>Matches</h1>
      <button type="button" onClick={handleShuffleMatches}>
        Shuffle Matches
      </button>
      <ul>
        {matches.map((match, index) => (
        <li key={index}>
            {match.home_team} vs {match.away_team}
        </li>
        ))}
      </ul>
      </div>
      );

    }